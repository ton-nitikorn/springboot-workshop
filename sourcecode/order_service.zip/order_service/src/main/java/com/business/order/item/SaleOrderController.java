package com.business.order.item;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 * SaleOrderController
 */
@RestController
@RequestMapping("/order")
public class SaleOrderController {

    private static final Logger LOGGER = LoggerFactory.getLogger(SaleOrderController.class);

    @Autowired
    SaleOrderRepository saleOrderRepository;

    @Autowired
    RestTemplate restTemplate;

    @HystrixCommand(fallbackMethod = "getPromotionFallback")
    @GetMapping("/setPromotion/{id}/{promotionCode}")
    public Map<String, Object> findOrderById(
        @PathVariable Long id,
        @PathVariable String promotionCode
    ){
        LOGGER.info("call to promotion service");
        @SuppressWarnings("unchecked")
        Map<String, Object> promotion = restTemplate.getForObject(
            "http://promotion-service/promotion/"+promotionCode, Map.class);
        LOGGER.info("response from promotion");
        
        Map<String, Object> res = new HashMap<>();
        Optional<SaleOrder> saleOrder = saleOrderRepository.findById(id);
        if(saleOrder.isPresent()){
            SaleOrder sale = saleOrder.get();
            Double net = sale.getNet() - Double.parseDouble(promotion.get("discount").toString());
            res.put("id", id);
            res.put("promotion", promotionCode);
            res.put("subnet", sale.getNet());
            res.put("discount", promotion.get("discount"));
            res.put("net", net);
        }else{
            res.put("success", false);
            res.put("message", "No data found.");
        }

        return res;
    }

    public Map<String, Object> getPromotionFallback(Long id, String promotionCode, Throwable hystrixCommand) {
        Map<String, Object> result = new HashMap<>();
        System.out.println(hystrixCommand.getMessage());
        result.put("success", false);
        result.put("message", hystrixCommand.getMessage());
        return result;
    }

}