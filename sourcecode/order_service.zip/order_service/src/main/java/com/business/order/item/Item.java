package com.business.order.item;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * Item
 */
@Entity
public class Item {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="saleOrderId")
    private SaleOrder saleOrder;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="productId")
    private Product product;

    private Integer qty;

    public Item(){
        
    }

    public Item(SaleOrder saleOrder, Product product, Integer qty){
        this.saleOrder = saleOrder;
        this.product = product;
        this.qty = qty;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the saleOrder
     */
    public SaleOrder getSaleOrder() {
        return saleOrder;
    }
    
    /**
     * @param saleOrder the saleOrder to set
     */
    public void setSaleOrder(SaleOrder saleOrder) {
        this.saleOrder = saleOrder;
    }

    /**
     * @return the product
     */
    public Product getProduct() {
        return product;
    }

    /**
     * @param product the product to set
     */
    public void setProduct(Product product) {
        this.product = product;
    }

    /**
     * @return the qty
     */
    public Integer getQty() {
        return qty;
    }

    /**
     * @param qty the qty to set
     */
    public void setQty(Integer qty) {
        this.qty = qty;
    }
}