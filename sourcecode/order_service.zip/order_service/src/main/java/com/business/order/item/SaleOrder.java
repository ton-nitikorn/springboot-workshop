package com.business.order.item;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 * SaleOrder
 */
@Entity
public class SaleOrder {

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Date date;
    private String status;
    private String promotion;
    private Double subnet;
    private Double discount;
    private Double net;
    
    @OneToMany( mappedBy="saleOrder", cascade=CascadeType.ALL)
    private Set<Item> items;

    public SaleOrder(){

    }

    public SaleOrder(
        Date date, String status, String promotion, 
        Double subnet, Double discount, Double net, 
        Set<Item> items){
            this.date = date;
            this.status = status;
            this.promotion = promotion;
            this.subnet = subnet;
            this.discount = discount;
            this.net = net;
            this.items = items;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the date
     */
    public Date getDate() {
        return date;
    }
    /**
     * @param date the date to set
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * @return the promotion
     */
    public String getPromotion() {
        return promotion;
    }

    /**
     * @param promotion the promotion to set
     */
    public void setPromotion(String promotion) {
        this.promotion = promotion;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the subnet
     */
    public Double getSubnet() {
        return subnet;
    }
    
    /**
     * @param subnet the subnet to set
     */
    public void setSubnet(Double subnet) {
        this.subnet = subnet;
    }

    /**
     * @return the discount
     */
    public Double getDiscount() {
        return discount;
    }

    /**
     * @param discount the discount to set
     */
    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    /**
     * @return the net
     */
    public Double getNet() {
        return net;
    }

    /**
     * @param net the net to set
     */
    public void setNet(Double net) {
        this.net = net;
    }
}