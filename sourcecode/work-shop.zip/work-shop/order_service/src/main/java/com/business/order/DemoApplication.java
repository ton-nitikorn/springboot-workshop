package com.business.order;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.business.order.item.Item;
import com.business.order.item.ItemRepository;
import com.business.order.item.Product;
import com.business.order.item.ProductRepository;
import com.business.order.item.SaleOrder;
import com.business.order.item.SaleOrderRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableEurekaClient
@EnableCircuitBreaker
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Bean
	@LoadBalanced
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	@Bean
	public CommandLineRunner initialData(ProductRepository productRepo, SaleOrderRepository saleRepo,
			ItemRepository itemRepo) {
		return (args) -> {

			List<Product> products = new ArrayList<>();
			products.add(new Product("10001", "Java Version 1.0", "pct", 100d));
			products.add(new Product("10002", "Spring Boot", "pct", 230d));
			products.add(new Product("10003", "Spring Boot ver. 2.3", "pct", 230d));
			productRepo.saveAll(products);

			Set<Item> items = new HashSet<Item>();
			SaleOrder saleOrder = new SaleOrder(new Date(), "Prepare", null, 0d, 0d, 330d, items);

			for (int i = 0; i < products.size(); i++) {
				items.add(new Item(saleOrder, products.get(i), 1));
			}

			saleRepo.save(saleOrder);
		};
	}

}
