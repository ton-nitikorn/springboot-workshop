package com.business.order.item;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Item {

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="saleOrderId")
    private SaleOrder saleOrder;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="productId")
    private Product product;

    private Integer qty;

    public Item(SaleOrder saleOrder, Product product, Integer qty){
        this.saleOrder = saleOrder;
        this.product = product;
        this.qty = qty;
    }
}