package com.business.order.item;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@NoArgsConstructor
public class Product {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @Column(unique=true)
    private String sku;
    private String name;
    private String uom;
    private Double price;

    public Product(String sku, String name, String uom, Double price){
        this.sku = sku;
        this.name = name;
        this.uom = uom;
        this.price = price;
    }

}