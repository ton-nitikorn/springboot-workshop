package com.business.order;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.business.order.item.SaleOrder;
import com.business.order.item.SaleOrderController;
import com.business.order.item.SaleOrderRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

@RunWith(SpringRunner.class)
public class SaleOrderRepositoryTest {

    @MockBean
    private SaleOrderRepository saleRepository;

    @Before
    public void setup() {
        SaleOrder so = new SaleOrder();
        so.setNet(100d);

        Optional<SaleOrder> os = Optional.of(so);
        Mockito.when(saleRepository.findById(1l)).thenReturn(os);
    }

    @Test
    public void whenFindById_thenReturnNet() {
        SaleOrder sx = saleRepository.findById(1l).get();
        assertThat(sx.getNet()).isEqualTo(100d);
    }
}