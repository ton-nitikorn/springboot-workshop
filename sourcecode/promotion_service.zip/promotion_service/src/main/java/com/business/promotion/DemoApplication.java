package com.business.promotion;


import java.util.ArrayList;
import java.util.List;

import com.business.promotion.promo.Promotion;
import com.business.promotion.promo.PromotionRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableEurekaClient
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Bean
	public CommandLineRunner initialUserData(PromotionRepository repository) {
		return (args) -> {
			List<Promotion> promotion = new ArrayList<>();
			promotion.add(new Promotion("FREE100", 100d));
			promotion.add(new Promotion("FREE200", 200d));
			promotion.add(new Promotion("FREE150", 150d));
			repository.saveAll(promotion);
		};
	}
}
